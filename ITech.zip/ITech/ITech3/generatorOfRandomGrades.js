export const generateRandomGrades = () => {
  const gradeInputs = document.querySelectorAll('.grade');
  gradeInputs.forEach(input => {
      input.value = Math.floor(Math.random() * 4) + 2;
  });
}