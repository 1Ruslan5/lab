import  { generateRandomGrades } from "./generatorOfRandomGrades.js";

const students = [];
const categories = {
    "Excellent": 0,
    "Good": 0,
    "Average": 0,
    "Unsuccessful": 0,
};
const unsuccessfulStudents = [];
const addButton = document.querySelectorAll('.add-button');
const randomGradesButton = document.querySelectorAll('.generate-random-grades-button');

addButton[0].addEventListener('click', addStudent);
randomGradesButton[0].addEventListener('click', generateRandomGrades);

function addStudent() {
    const fullname = document.getElementById('fullname').value.trim();
    const gradeInputs = document.querySelectorAll('.grade');
    const grades = Array.from(gradeInputs).map(input => parseInt(input.value));

    if (!fullname || grades.some(isNaN)) {
        alert("Please enter the name and all grades");
        return;
    }

    const category = determineStudentCategory(grades);
    students.push({ fullname, category });
    categories[category]++;
    
    if (category === "Unsuccessful") {
      unsuccessfulStudents.push(fullname);
    }

    document.getElementById('fullname').value = '';
    gradeInputs.forEach(input => input.value = '');

    updateSummary();
}

function determineStudentCategory(grades) {
    if (grades.includes(2)) {
      return "Unsuccessful";
    }
    if (grades.every(grade => grade === 5)) {
      return "Excellent";
    }
    if (grades.every(grade => grade >= 4)) {
      return "Good";
    }
    
    return "Average";
}

function updateSummary() {
    const summary = `
        Excellent students: ${categories["Excellent"]}<br>
        Good students: ${categories["Good"]}<br>
        Average students: ${categories["Average"]}<br>
        Unsuccessful students: ${categories["Unsuccessful"]}<br>
    `;

    document.getElementById('summary').innerHTML = summary;
    const unsuccessfulList = document.getElementById('unsuccessful-list');
    unsuccessfulList.innerHTML = '';

    unsuccessfulStudents.forEach(fullname => {
        const li = document.createElement('li');
        li.textContent = fullname;
        unsuccessfulList.appendChild(li);
    });
}

